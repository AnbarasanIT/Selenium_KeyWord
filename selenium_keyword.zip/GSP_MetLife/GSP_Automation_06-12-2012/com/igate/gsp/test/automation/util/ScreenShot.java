package com.igate.gsp.test.automation.util;

public class ScreenShot 
{

}
