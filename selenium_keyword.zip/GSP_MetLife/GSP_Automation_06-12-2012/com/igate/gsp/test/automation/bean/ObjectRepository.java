package com.igate.gsp.test.automation.bean;

public class ObjectRepository {
	

		private String fieldName;
		private String locator;
		private String decription;
		private String type;
		
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getDecription() {
			return decription;
		}
		public void setDecription(String decription) {
			this.decription = decription;
		}
		public String getFieldName() {
			return fieldName;
		}
		public void setFieldName(String fieldName) {
			this.fieldName = fieldName;
		}
		public String getLocator() {
			return locator;
		}
		public void setLocator(String locator) {
			this.locator = locator;
		}
		
	
	

}
