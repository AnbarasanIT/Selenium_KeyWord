package com.igate.gsp.test.automation.engine;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.igate.gsp.test.automation.bean.Result;

public class Action 
{
	public static Result populateData(WebDriver driver, String locator, String data, String action)
	{
		//your code goes here
		System.out.println("Locator, Data and Action are : " + locator +" "+ data +" "+ action);
		//boolean result = false;
		Result result = new Result();

		if(action.equalsIgnoreCase("TYPE"))
		{
			result = type(driver, locator, data, result);
		}
		else if(action.equalsIgnoreCase("CLICK"))
		{
			result = click(driver, locator, result);
		}
		else if(action.equalsIgnoreCase("SELECT"))
		{
			result = select(driver, locator, data, result);
		}
		else if(action.equalsIgnoreCase("SET"))
		{
			result = set(driver, locator, data, result);
		}
		else if(action.equalsIgnoreCase("CLEAR"))
		{
			result = clear(driver, locator, result);
		}
		else if(action.equalsIgnoreCase("CHECKITEMEXISTENCE"))
		{
			result = checkItemExistence(driver, locator, data, result);
		}

		return result;
	}

	public static Result miscActions(WebDriver driver, String action, String data)
	{
		System.out.println("Misc Actions");
		Result result = new Result();

		if(action.equalsIgnoreCase("WAIT"))
		{
			result = wait(driver, data, result);
		}
		else if(action.equalsIgnoreCase("CHECKMESSAGE"))
		{
			result = checkMessage(driver, data, result);
		}
		else if(action.contains("HandleAlert"))
		{
			result = handleAlert(driver, data, action.substring(action.indexOf("|")+1, action.length()), result);
		}

		return result;
	}

	public static boolean verify(WebDriver driver, String data)
	{
		return false;
	}

	public static Result type(WebDriver driver, String locator, String data, Result result)
	{
		result.setExpectedResult("'" + data + "' should get entered.");

		if (getIdentifier(driver , locator) != null)
		{
			getIdentifier(driver, locator).clear();
			getIdentifier(driver , locator).sendKeys(data);

			result.setStatus("Pass");
			result.setActualResult("'"+ data +"' is entered.");
			result.setRemarks("NA");
		}
		else
		{
			result.setStatus("Fail");
			result.setActualResult("'"+ data +"' is not getting entered.");
			result.setRemarks("Unable to find element on the screen.");
		}
		return result;
	}

	public static Result select(WebDriver driver, String locator, String data, Result result)
	{
		result.setExpectedResult("'" + data + "' should get selected.");
		if (getIdentifier(driver , locator) != null)
		{
			new Select(getIdentifier(driver , locator)).selectByVisibleText(data);
						
			result.setStatus("Pass");
			result.setActualResult("'" + data + "' is getting selected.");
			result.setRemarks("NA");
		}
		else
		{
			result.setStatus("Fail");
			result.setActualResult("'" + data + "' is not getting selected.");
			result.setRemarks("Unable to find element on the screen.");
		}
		return result;
	}

	public static Result click(WebDriver driver, String locator, Result result)
	{
		result.setExpectedResult("Button / Link should get clicked.");

		if (getIdentifier(driver , locator) != null)
		{
			getIdentifier(driver , locator).click();

			result.setStatus("Pass");
			result.setActualResult("Button / Link is clicked.");
			result.setRemarks("NA");
		}
		else
		{
			result.setStatus("Fail");
			result.setActualResult("Button / Link is not clicked.");
			result.setRemarks("Unable to find element on the screen.");
		}
		return result;
	}

	public static Result wait(WebDriver driver, String data, Result result)
	{
		result.setExpectedResult("It should wait for '" + data + "' seconds"); 
		try 
		{
			Thread.sleep((1000 * Integer.valueOf(data)));
			
			result.setStatus("Pass");
			result.setActualResult("It has waited for '" + data + "' seconds");
			result.setRemarks("NA");
		
		}
		catch (NumberFormatException e) 
		{
			result.setStatus("Fail");
			result.setActualResult("It has not waited for '" + data + "' seconds");
			result.setRemarks("Duration is not valid.");
		} 
		catch (InterruptedException e) 
		{
			result.setStatus("Fail");
			result.setActualResult("It has not waited for '" + data + "' seconds");
			result.setRemarks("Technical issue.");
		}

		return result;
	}

	public static Result checkMessage(WebDriver driver, String data, Result result)
	{
		result.setExpectedResult("'" + data + "' should be present on the screen as Message."); 
		
		if(driver.getPageSource().contains(data))
		{
			result.setStatus("Pass");
			result.setActualResult("'" + data + "' is present on the screen as Message.");
			result.setRemarks("NA");
		}
		else
		{
			result.setStatus("Fail");
			result.setActualResult("'" + data + "' is not present on the screen as Message.");
			result.setRemarks("NA");
		}
		return result;
	}

	public static Result set(WebDriver driver, String locator, String data, Result result)
	{
		
		if(getIdentifier(driver, locator) != null)
		{
			boolean isChecked = getIdentifier(driver, locator).isSelected();
			System.out.println("Boolean value " + isChecked);
			
			if(data.equalsIgnoreCase("ON") && isChecked == false)
			{
				result.setExpectedResult("Radio button / Checkbox should get checked.");
				getIdentifier(driver, locator).click();
								
				result.setStatus("Pass");
				result.setActualResult("Radio button / Checkbox is checked.");
				result.setRemarks("NA");
			}
			else if(data.equalsIgnoreCase("OFF") && isChecked == true)
			{
				// code is not available yet.
				result.setExpectedResult("Radio button / Checkbox should get unchecked.");
				getIdentifier(driver, locator).click();
								
				result.setStatus("Pass");
				result.setActualResult("Radio button / Checkbox is unchecked.");
				result.setRemarks("NA");
			}
		}
		else
		{
			result.setExpectedResult("Radio button / Checkbox should get checked / unchecked.");
			result.setStatus("Fail");
			result.setActualResult("Radio button / Checkbox is not checked / unchecked.");
			result.setRemarks("Unable to find element on the screen.");
		}
		
		return result;
	}

	public static Result clear(WebDriver driver, String locator, Result result)
	{
		result.setExpectedResult("It should clear the element.");
		
		if(getIdentifier(driver, locator) != null)
		{
			getIdentifier(driver, locator).clear();
			
			
			result.setStatus("Pass");
			result.setActualResult("Element is getting cleared.");
			result.setRemarks("NA");
		}
		else
		{
			result.setStatus("Fail");
			result.setActualResult("Element is not getting cleared.");
			result.setRemarks("Unable to find element on the screen.");
		}

		return result;
	}

	public static Result checkItemExistence(WebDriver driver, String locator, String data, Result result)
	{
		result.setExpectedResult("'" + data + "' should be present into select box.");
		try
		{
			List<WebElement> options = getIdentifier(driver, locator).findElements(By.tagName("option"));
			boolean isFound = false;
			for(WebElement option : options)
			{
				if(data.equals(option.getText()))
				{
					isFound = true;
					break;
				}
			}
			
			if(isFound)
			{
				result.setStatus("Pass");
				result.setActualResult("'" + data + "' is present into select box.");
				result.setRemarks("NA");
			}
			else
			{
				result.setStatus("Fail");
				result.setActualResult("'" + data + "' is not present into select box.");
				result.setRemarks("NA");
			}
		}
		catch(NullPointerException e)
		{
			result.setStatus("Fail");
			result.setActualResult("Cannot check for '"+ data +"' presence into select box.");
			result.setRemarks("Unable to find element on the screen.");
		}
		
		return result;
	}

	public static Result handleAlert(WebDriver driver, String data, String action, Result result)
	{
		try
		{
			result.setExpectedResult("Alert shoult come with text '" + data + "'");
			
			Alert alert = driver.switchTo().alert(); 
			if(alert.getText().equals(data))
			{
				result.setStatus("Pass");
				result.setActualResult("Alert is coming with text '" + data + "'");
				result.setRemarks("NA");
			}
			else
			{
				result.setStatus("Fail");
				result.setActualResult("Alert is not coming with text '" + data + "'");
				result.setRemarks("NA");
			}

			if(action.equalsIgnoreCase("OK"))
			{
				alert.accept();
			}
			else if(action.equalsIgnoreCase("CANCEL"))
			{
				alert.dismiss();
			}
		}
		catch(Exception e)
		{
			result.setStatus("Fail");
			result.setActualResult("Alert is not present on screen.");
			result.setRemarks("NA");
		}
		
		return result;
	}

	public static WebElement getIdentifier(WebDriver driver ,String locator)
	{
		WebElement webElement =null;
		try
		{
			webElement = driver.findElement(By.id(locator));
			return webElement;
		}
		catch(Exception e){}
		try
		{
			webElement = driver.findElement(By.name(locator));
			return webElement;
		}
		catch(Exception e){}

		try
		{
			webElement = driver.findElement(By.cssSelector(locator));
			return webElement;
		}
		catch(Exception e){}

		try
		{
			webElement = driver.findElement(By.xpath(locator));
			return webElement;
		}
		catch(Exception e){}

		return webElement;
	}
}
