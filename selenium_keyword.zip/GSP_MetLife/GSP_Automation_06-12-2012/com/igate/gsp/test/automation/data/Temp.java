
 package com.igate.gsp.test.automation.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
 /*
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.igate.gsp.test.automation.bean.InputSheet;
import com.igate.gsp.test.automation.bean.ObjectRepository;
import com.igate.gsp.test.automation.util.DriverManager;*/
public class Temp {


	//private final String dataConfigFile = "Data//DataConfig.properties";
	//private static Map<String,String> dataConfigMap = new LinkedHashMap<String, String>();
	/*private static List<ObjectRepository> ORList;
	private static Map<String,String> ORMap = new LinkedHashMap<String, String>();
	private static List<InputSheet> inputSheetData;
	public static WebDriver driver;
       public static Row row=null;
	*/
	public static void main(String args[])
	{
		System.out.println("HandleAlert|OK".substring("HandleAlert|OK".indexOf("|") + 1, "HandleAlert|OK".length()));
		
		Map<String, List> data = new LinkedHashMap<String, List>();
		
		List<String> data1 = new ArrayList<String>();
		List<String> res;
		data1.add("Hussain");
		data1.add("PP");
		
		data.put("h", data1);
		
		data1.add("zz");
		data.put("s", data1);
		
		Set<String> set = data.keySet();
		
		for(String k : set)
		{
			res = data.get(k);
			for(String g : res)
			{
				System.out.println(g);
			}
		}
		
	}
}/*String Datasheet ="D://Ebiz//3. GSP//Test Support//Automation Testing//Input//OR1.xls";
		String Datasheet1 ="D://Ebiz//3. GSP//Test Support//Automation Testing//Input//AUTO_Login_Happy Path.xls";
		
		try 
		{
			InputStream ins = new FileInputStream(Datasheet);
			Workbook wb = WorkbookFactory.create(ins);
			
			Sheet sheet = wb.getSheet("Login");
			
			int totalRows = sheet.getPhysicalNumberOfRows();
			ObjectRepository or ; 
			ORList = new ArrayList<ObjectRepository>();
			
			for(int i = 1; i < totalRows ; i++)
			{
				System.out.println("count" + i);
				 row = sheet.getRow(i);
				or = new ObjectRepository();
								
				or.setFieldName(row.getCell(0).toString());
				or.setLocator(row.getCell(1).toString());
				or.setType(row.getCell(2).toString());
				or.setDecription(row.getCell(3).toString());
				
				ORMap.put(row.getCell(0).toString(), row.getCell(1).toString());
				ORList.add(or);
			}
			System.out.println("OR Read successfully");
			
			ins = new FileInputStream(Datasheet1);
			Workbook wbook = WorkbookFactory.create(ins);
			
			Sheet inputSheet = wbook.getSheet("TestScript");
			totalRows = inputSheet.getPhysicalNumberOfRows();
			
			//InputSheet objInputSheet=null;
			inputSheetData = new ArrayList<InputSheet>();
			
			for(int i=1; i< totalRows ; i++)
			{
				InputSheet objInputSheet= new InputSheet();		
				row = inputSheet.getRow(i);
				objInputSheet.setSerialNumber(row.getCell(0).toString());
				objInputSheet.setPageName(row.getCell(1).toString());
				objInputSheet.setFieldName(row.getCell(2).toString());
				objInputSheet.setAction(row.getCell(3).toString());
				objInputSheet.setDataValue(row.getCell(4).toString());
		        
				inputSheetData.add(objInputSheet);
			}
			System.out.println("Input Sheet Read successfully");
			
			
			DriverManager.getInstance().setBrowserStr("FF");
			DriverManager.getInstance().initDriver();
			driver = DriverManager.getInstance().getDriver();
			
			
			driver.get("http://172.19.32.247:9081/sales/login");
			
			for(InputSheet in : inputSheetData)
			{
				if("Login".equals(in.getPageName()))
				{
					String locator = ORMap.get(in.getFieldName());
					
					if("Type".equals(in.getAction()))
					{
						DriverManager.getInstance().getDriver().findElement(By.id(locator)).sendKeys(in.getDataValue());
					}
					else if("Click".equals(in.getAction()))
					{
						DriverManager.getInstance().getDriver().findElement(By.id(locator)).click();
					}
					else 
					{
						System.out.println("no Action");
					}
				}
				else
				{
					System.out.println("No Login");
				}
			}
			System.out.println("done with input sheet travesal");
		} 
		catch (FileNotFoundException e) 
		{		
			e.printStackTrace();
		}
		catch (InvalidFormatException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			driver.quit();
		}
	}
}
*/