package com.igate.gsp.test.automation.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;



public class Config {
	
	public static void getConfigurations()
	{
		Properties properties = new Properties();
		String filePath="Configuration/Config.properties";
		try {
			properties.load(new FileInputStream(filePath));			
			GlobalVariables.Browser= properties.getProperty("Browser");		
			GlobalVariables.FF_Profile= properties.getProperty("FF_Profile");			
			GlobalVariables.ReportPath= properties.getProperty("ReportPath");			
			GlobalVariables.URL= properties.getProperty("URL");
			GlobalVariables.ScreenShotPath=properties.getProperty("ScreenshotPath");
			GlobalVariables.ObjectRepositoryPath=properties.getProperty("ObjectRepositoryPath");
			GlobalVariables.InputSheetPath=properties.getProperty("AutomationTestScriptPath");
			GlobalVariables.LoggingPath=properties.getProperty("LoggingPath");
		}
		catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}



}
