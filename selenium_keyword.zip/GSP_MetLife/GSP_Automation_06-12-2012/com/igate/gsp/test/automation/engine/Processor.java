package com.igate.gsp.test.automation.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.igate.gsp.test.automation.bean.InputSheet;
import com.igate.gsp.test.automation.bean.ObjectRepository;
import com.igate.gsp.test.automation.bean.OutputSheet;
import com.igate.gsp.test.automation.bean.Result;
import com.igate.gsp.test.automation.util.DriverManager;
import com.igate.gsp.test.automation.util.GlobalVariables;

@SuppressWarnings("unchecked") 
public class Processor 
{
	static WebDriver driver = null;
	List<OutputSheet> outputSheetData;
	Result result = null;
	OutputSheet outputSheet = null;
	
	public void process(String testCase)
	{
		Map<String, ObjectRepository> pageList = null;
		outputSheetData = new ArrayList<OutputSheet>();
		System.out.println("Out Side the loop " + GlobalVariables.inputSheet.size());

		// W E B  D R I V E R
		loadDriver();

		List<InputSheet> inputSheetData = GlobalVariables.inputSheet.get(testCase);
				
		for(InputSheet inputSheet : inputSheetData)
		{
			System.out.println("Inside Loop");
			if(inputSheet.getPageName().equals("NA"))
			{
				result = Action.miscActions(driver, inputSheet.getAction(), inputSheet.getDataValue());
			}
			else
			{
				System.out.println("Page name : " + inputSheet.getPageName());
				pageList = GlobalVariables.objectRepository.get(inputSheet.getPageName());			

				System.out.println("Count of Elements in sheet : " + pageList.size());

				ObjectRepository objectRepository = pageList.get(inputSheet.getFieldName());
				System.out.println("Field Name : " + objectRepository.getLocator());

				result = Action.populateData(driver, objectRepository.getLocator(), inputSheet.getDataValue(), inputSheet.getAction());
			}
			
			setReportData(inputSheet, result); 
		}
		
		GlobalVariables.outputSheet.put(testCase.toUpperCase(), outputSheetData);
		quitDriver();
	}
	
	public void setReportData(InputSheet inputSheet, Result result)
	{
		outputSheet = new OutputSheet();
		
		outputSheet.setSerialNumber(inputSheet.getSerialNumber());
		outputSheet.setPageName(inputSheet.getPageName());
		outputSheet.setFieldName(inputSheet.getFieldName());
		outputSheet.setAction(inputSheet.getAction());
		outputSheet.setDataValue(inputSheet.getDataValue());
		
		outputSheet.setExpectedResult(result.getExpectedResult());
		outputSheet.setActualResult(result.getActualResult());
		outputSheet.setStatus(result.getStatus());
		outputSheet.setRemarks(result.getRemarks());
		
		outputSheetData.add(outputSheet);
	}
	
	public void loadDriver()
	{
		//setting the driver and loading the initial page here
		driver = DriverManager.getInstance();
		driver.get(GlobalVariables.URL);
	}
	
	public void quitDriver()
	{
		driver.quit();
	}
}
