package com.igate.gsp.test.automation.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/*******************************************************************************

 * iGATE Corporation. 

 * Project     : GSP (Global Sales Platform) 

 * Program     : DriverManager.java 

 * Author      : iGate 

 * Date        : Oct-2012 

 * Description : This class gives an instance of driver and also the functionality to close and quit driver.

 * Revision Log (mm/dd/yy initials description)

 * --------------------------------------------
 * iGate 31/10/12 Created

 ******************************************************************************/
public class DriverManager 
{
	private static WebDriver driver;

	protected static final String FF_PROFILE = "FF_Profile";
	protected static final String FIREFOX = "FF";
	protected static final String IE = "IE";
	protected static final String CHROME = "Chrome";

	public static WebDriver getInstance()
	{
			initDriver();
			return driver;
	}

	public WebDriver getDriver() 
	{
		return driver;
	}

	/** 
	 * Description : This method do initialization based on the driver required.
	 * @param      : NA
	 * @author     : Automation Team
	 */
	public static void initDriver() 
	{
		if(IE.equalsIgnoreCase(GlobalVariables.Browser))
		{
			driver = (new InternetExplorerDriver());
		}
		else if(FIREFOX.equalsIgnoreCase(GlobalVariables.Browser))
		{		
			driver = (new FirefoxDriver());
		}
		else if(CHROME.equalsIgnoreCase(GlobalVariables.Browser))
		{
			driver = (new ChromeDriver());
		}
		else
		{
			driver = (new FirefoxDriver());
		}
	}

	public void closeDriver()
	{
		driver.close();
	}

	public void quitDriver()
	{
		driver.quit();
		driver = null;
	}
}
