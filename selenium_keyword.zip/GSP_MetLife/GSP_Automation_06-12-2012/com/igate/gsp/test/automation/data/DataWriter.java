package com.igate.gsp.test.automation.data;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;


import com.igate.gsp.test.automation.bean.OutputSheet;
import com.igate.gsp.test.automation.util.GlobalVariables;

public class DataWriter 
{
	private static HSSFWorkbook workBook = new HSSFWorkbook();
	List<OutputSheet> sheetData = null;
	
	public void createAutomationTestExecutionReport()
	{
		// createSummarySheet();
		createTestReportSheets();

		//writing to physical file
		writeToPhysicalFile();
	}
	
	private void writeToPhysicalFile()
	{
		FileOutputStream fos;
		try 
		{
			fos = new FileOutputStream(GlobalVariables.ReportPath + "Report.xls");
			workBook.write(fos);
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	private void createTestReportSheets()
	{
		// creating all header formats.
		CellStyle failStyle = getFailStyle();
		CellStyle passStyle = getPassStyle();
		
		HSSFCell cell;
		
		//creating workbook
		
		Set<String> set = GlobalVariables.outputSheet.keySet();
		
		for(String sheetName : set)
		{
			sheetData = GlobalVariables.outputSheet.get(sheetName);
			HSSFSheet sheet = workBook.createSheet(sheetName);
			
			putHeaderRow(sheet);
			
			int rowPointer = 1;
			for(OutputSheet reportData : sheetData)
			{
				HSSFRow row = sheet.createRow(rowPointer);
				
				cell = row.createCell(0);
				cell.setCellValue(reportData.getSerialNumber());
				
				cell = row.createCell(1);
				cell.setCellValue(reportData.getPageName());
				
				cell = row.createCell(2);
				cell.setCellValue(reportData.getFieldName());
				
				cell = row.createCell(3);
				cell.setCellValue(reportData.getAction());
				
				cell = row.createCell(4);
				cell.setCellValue(reportData.getDataValue());
				
				cell = row.createCell(5);
				cell.setCellValue(reportData.getExpectedResult());
				
				cell = row.createCell(6);
				cell.setCellValue(reportData.getActualResult());
				
				cell = row.createCell(7);
				
				if(reportData.getStatus().equalsIgnoreCase("PASS"))
				{
					cell.setCellStyle(passStyle);
				}
				else
				{
					cell.setCellStyle(failStyle);
				}

				cell.setCellValue(reportData.getStatus());
				
				cell = row.createCell(8);
				cell.setCellValue(reportData.getRemarks());

				rowPointer += 1;
			}
		}
	}
	
	
	private void putHeaderRow(HSSFSheet sheet)
	{
		CellStyle headerFormat = getHeaderStyle();
		
		HSSFRow row = sheet.createRow(0);

		HSSFCell cell = row.createCell(0);
		
		cell.setCellStyle(headerFormat);
		cell.setCellValue("S. NO");

		cell = row.createCell(1);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("PAGE");

		cell = row.createCell(2);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("FIELD");

		cell = row.createCell(3);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("ACTION");

		cell = row.createCell(4);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("DATA | PARAMETER");

		cell = row.createCell(5);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("EXPECTED RESULT");

		cell = row.createCell(6);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("ACTUAL RESULT");

		cell = row.createCell(7);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("STATUS");
		
		cell = row.createCell(8);
		cell.setCellStyle(headerFormat);
		cell.setCellValue("REMARKS");
		
	}
	private CellStyle getFailStyle()
	{
		Font failFont = workBook.createFont();
		failFont.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		failFont.setColor(IndexedColors.RED.getIndex());

		CellStyle style = workBook.createCellStyle();
		style.setFont(failFont);

		return style;
	}
	
	private CellStyle getPassStyle()
	{
		Font passFont = workBook.createFont();
		passFont.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		passFont.setColor(IndexedColors.GREEN.getIndex());

		CellStyle style = workBook.createCellStyle();
		style.setFont(passFont);

		return style;
	}
	
	private static CellStyle getHeaderStyle()
	{
		Font headerFont = workBook.createFont();
		headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		headerFont.setColor(IndexedColors.WHITE.getIndex());

		CellStyle style = workBook.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex()); 

		style.setAlignment(CellStyle.ALIGN_GENERAL);
		style.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(headerFont);

		return style;
	}
}
