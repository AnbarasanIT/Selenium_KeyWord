package com.igate.gsp.test.automation.engine;

import java.util.Scanner;

import com.igate.gsp.test.automation.data.DataReader;
import com.igate.gsp.test.automation.data.DataWriter;
import com.igate.gsp.test.automation.exception.GSPAutomationException;
import com.igate.gsp.test.automation.util.Config;

public class Engine 
{
	public static void main(String[] args) {

		//Scanner scanner = new Scanner(System.in);
		try
		{
			// reading configuration information from the file
			Config.getConfigurations();
			
			// Reading the InputSheet and OR and storing them into java objects.
			new DataReader().getDataIntoSystem();
			boolean isContinue = true;
			
			Scanner scanner = new Scanner(System.in);
			
			while(isContinue)
			{
				System.out.println("Enter Sheet Name :");
				String testCase = scanner.nextLine();

				// Execute the test case	
				new Processor().process(testCase);
				
				System.out.println("Do you want to continue ? \nPress 1 to continue");
				String userChoice = scanner.nextLine();
				
				if(!userChoice.equalsIgnoreCase("1"))
				{
					isContinue = false;
				}
			}
		
			// Prepare report
			new DataWriter().createAutomationTestExecutionReport();
			
		}
		catch(GSPAutomationException e)
		{
			System.err.println("Error :" + e.getMessage());
		}
	}
}
