package com.igate.gsp.test.automation.exception;

@SuppressWarnings("serial")
public class GSPAutomationException extends Exception
{
	public GSPAutomationException(String message)
	{
		super(message);
	}
}
