package com.igate.gsp.test.automation.data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.igate.gsp.test.automation.bean.InputSheet;
import com.igate.gsp.test.automation.bean.ObjectRepository;
import com.igate.gsp.test.automation.exception.GSPAutomationException;
import com.igate.gsp.test.automation.util.GlobalVariables;

public class DataReader
{
	InputStream inputStream = null;
	Workbook workbook = null;
	Map<String, Map> OR = null;
	Map<String, List> InputSheetData;
	List<InputSheet> inputSheet = null;
	//private final String TEST_SCRIPT_SHEET = "TestScript";
	
	public boolean getDataIntoSystem() throws GSPAutomationException
	{															
		GlobalVariables.objectRepository = getORIntoMap();
		GlobalVariables.inputSheet = getInputSheetIntoMap();
		
		return false;
	}

	public Map<String, Map> getORIntoMap() throws GSPAutomationException
	{
		try 
		{
			try 
			{
				inputStream = new FileInputStream(GlobalVariables.ObjectRepositoryPath);
				workbook = WorkbookFactory.create(inputStream);

				OR = new HashMap<String, Map>();
				Map<String, ObjectRepository> ORData = null;
				ObjectRepository objectRepository = null;
				int sheetCount = workbook.getNumberOfSheets();
                System.out.println("OR Sheet count is :"+ sheetCount );
				for(int i = 0; i < sheetCount; i++)
				{
					Sheet sheet = workbook.getSheetAt(i);

					int totalRows = sheet.getPhysicalNumberOfRows();
					ORData = new HashMap<String, ObjectRepository>();

					for(int j = 1; j < totalRows ; j++)
					{
						Row row = sheet.getRow(j);

						objectRepository = new ObjectRepository();
						objectRepository.setFieldName(row.getCell(0).toString());
						objectRepository.setLocator(row.getCell(1).toString());
						objectRepository.setType(row.getCell(2).toString());
						try
						{
							objectRepository.setDecription(row.getCell(3).toString());
						}
						catch(NullPointerException e)
						{
							objectRepository.setDecription("NA");
						}

						ORData.put(row.getCell(0).toString(), objectRepository);
					}

					OR.put(sheet.getSheetName(), ORData);
				}
				System.out.println("-- OR read successfully --");
			}
			catch (FileNotFoundException e) 
			{
				throw new GSPAutomationException("OR File not found or its locked by some other process.");
			}
			catch (InvalidFormatException e) 
			{
				throw new GSPAutomationException("OR File Format is not valid.");
			}
			catch (IOException e)
			{
				throw new GSPAutomationException("Could not read from the File.");
			}
			finally
			{
				workbook = null;
				inputStream.close();
				inputStream = null;
			}
		} 
		catch (IOException e) 
		{
			throw new GSPAutomationException("Technical Error at the time of closing file.");
		}
		return OR;
	}

	
	public Map<String, List> getInputSheetIntoMap() throws GSPAutomationException
	{
		try
		{
			try
			{
				inputStream = new FileInputStream(GlobalVariables.InputSheetPath);
				workbook = WorkbookFactory.create(inputStream);
				
				int sheetCount = workbook.getNumberOfSheets();
				System.out.println("Automation Test Input Sheet Count: " + sheetCount);
				
				InputSheetData = new HashMap<String, List>();
				
				for(int i = 1; i < sheetCount ; i++)
				{
					Sheet sheet = workbook.getSheetAt(i);
					int totalRows = sheet.getPhysicalNumberOfRows();
					System.out.println("Input Sheet Name: " + sheet.getSheetName());
					
					inputSheet = new ArrayList<InputSheet>();
					
					InputSheet inputSheetRecord = null ; 
					
					for(int j = 1; j < totalRows ; j++)
					{
						Row row = sheet.getRow(j);
						inputSheetRecord = new InputSheet();
						
						inputSheetRecord.setSerialNumber(row.getCell(0).toString());
						
						try
						{
							inputSheetRecord.setPageName(row.getCell(1).toString());	
						}
						catch(NullPointerException e)
						{
							inputSheetRecord.setPageName("NA");	
						}
						
						try
						{
							inputSheetRecord.setFieldName(row.getCell(2).toString());
						}
						catch(NullPointerException e)
						{
							inputSheetRecord.setFieldName("NA");
						}
						
						inputSheetRecord.setAction(row.getCell(3).toString());
						
						try
						{
							inputSheetRecord.setDataValue(row.getCell(4).toString());	
						}
						catch(NullPointerException e)
						{
							inputSheetRecord.setDataValue("NA");	
						}
						
						inputSheet.add(inputSheetRecord);
					}
					
					InputSheetData.put(sheet.getSheetName(), inputSheet);
					System.out.println("-- Inputsheet read successfully --");
				}
			}
			catch (FileNotFoundException e) 
			{
				throw new GSPAutomationException("InputSheet File not found or its locked by some other process.");
			}
			catch (InvalidFormatException e) 
			{
				throw new GSPAutomationException("InputSheet File Format is not valid.");
			}
			catch (IOException e)
			{
				throw new GSPAutomationException("Could not read from the File.");
			}
			catch (NullPointerException e)
			{
				e.printStackTrace();
				throw new GSPAutomationException("Either S. No or Action Feild is blank into current input sheet");
			}
			finally
			{
				workbook = null;
				inputStream.close();
				inputStream = null;
			}
		} 
		catch (IOException e) 
		{
			throw new GSPAutomationException("Technical Error at the time of closing file.");
		}
		
		return InputSheetData;
	}
	
	/*public List<InputSheet> getInputSheetIntoArrayList() throws GSPAutomationException
	{
		try
		{
			try
			{
				inputStream = new FileInputStream(GlobalVariables.InputSheetPath);
				workbook = WorkbookFactory.create(inputStream);
				
				Sheet sheet = workbook.getSheet(TEST_SCRIPT_SHEET);
				
				int totalRows = sheet.getPhysicalNumberOfRows();
				Row row = null;
				
				inputSheet = new ArrayList<InputSheet>();
				InputSheet inputSheetData = null;
				
				for(int i = 1; i < totalRows ; i++)
				{
					row = sheet.getRow(i);
					
					inputSheetData = new InputSheet();
					
					inputSheetData.setSerialNumber(row.getCell(0).toString());
					
					try
					{
						inputSheetData.setPageName(row.getCell(1).toString());	
					}
					catch(NullPointerException e)
					{
						inputSheetData.setPageName("NA");	
					}
					
					try
					{
						inputSheetData.setFieldName(row.getCell(2).toString());
					}
					catch(NullPointerException e)
					{
						inputSheetData.setFieldName("NA");
					}
					
					inputSheetData.setAction(row.getCell(3).toString());
					
					try
					{
						inputSheetData.setDataValue(row.getCell(4).toString());	
					}
					catch(NullPointerException e)
					{
						inputSheetData.setDataValue("NA");	
					}
					
					inputSheet.add(inputSheetData);
				}
				
				System.out.println("-- Inputsheet read successfully --");
			}
			catch (FileNotFoundException e) 
			{
				throw new GSPAutomationException("InputSheet File not found or its locked by some other process.");
			}
			catch (InvalidFormatException e) 
			{
				throw new GSPAutomationException("InputSheet File Format is not valid.");
			}
			catch (IOException e)
			{
				throw new GSPAutomationException("Could not read from the File.");
			}
			catch (NullPointerException e)
			{
				throw new GSPAutomationException("Either S. No or Action Feild is blank into current input sheet");
			}
			finally
			{
				workbook = null;
				inputStream.close();
				inputStream = null;
			}
		} 
		catch (IOException e) 
		{
			throw new GSPAutomationException("Technical Error at the time of closing file.");
		}
		return inputSheet;
	}*/
}
