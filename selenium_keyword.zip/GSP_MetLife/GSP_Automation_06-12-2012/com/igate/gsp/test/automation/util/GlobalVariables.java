package com.igate.gsp.test.automation.util;


import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.thoughtworks.selenium.Selenium;

public class GlobalVariables {


	public static String URL;
	public static String FF_Profile;
	public static String Browser ;
	public static String ScreenShotPath;
	public static String ObjectRepositoryPath;
	public static String InputSheetPath;
	public static String ReportPath ;
	public static String LoggingPath ;
	public static Selenium selenium;

	// Map representing the Object repository having key value pair as key presents the screen and 
	// value which is the map containg element information of respective key 

	public static Map<String , Map> objectRepository;
	public static Map<String , List> inputSheet;
	public static Map<String, List> outputSheet = new LinkedHashMap<String, List>();
}
